# PocketDeck Ultra — Android + Windows

**120 frei belegbare Tasten auf 10 Seiten**, mit 100+ Aktionsarten. Die Android-App sendet Befehle im lokalen WLAN an den Windows-Python-Empfänger.

## Windows
1. Python 3.11+ installieren und bei Installation „Add Python to PATH“ wählen.
2. `windows/start_receiver.bat` ausführen; Abhängigkeiten werden installiert.
3. IP-Adresse und Verbindungscode aus dem Terminal notieren. Windows-Firewall muss eingehende Verbindungen auf TCP 8765 im **privaten** Netzwerk erlauben.

## Android APK auf GitHub bauen
1. ZIP entpacken und **Inhalt** (auch `.github`) in ein neues GitHub-Repository hochladen.
2. GitHub → Actions → Build Android APK → Run workflow.
3. APK aus den Workflow-Artefakten herunterladen und installieren.
4. Handy und PC mit demselben WLAN verbinden, IP und Code eintragen.

## Bedienung
- 10 Seiten mit je 12 Tasten; **lange drücken** zum Belegen.
- Für `Eigener Hotkey` Wert wie `ctrl+shift+s` eintragen.
- Für `Text eingeben` den gewünschten Text eintragen.
- Für `URL öffnen` eine vollständige `https://...`-Adresse eintragen.
- Für `Makro` eine kommagetrennte Folge der erlaubten Aktionen eingeben (maximal 12 Schritte).
- Der Lautstärkeregler steuert die Windows-Gesamtlautstärke.

## Sicherheit und Grenzen
Nur im vertrauenswürdigen WLAN nutzen. Der Empfänger hat einen zufälligen Zugriffscode, aber **keine TLS-Verschlüsselung**; kein Portforwarding ins Internet einrichten. Befehle werden auf dem Windows-PC ausgeführt, auf dem der Empfänger läuft. Nicht jede Windows-Tastenkombination funktioniert in jeder Anwendung. OBS-, Discord- und Spotify-API-Integrationen sind **nicht** implementiert. APK-Build und Gerätebetrieb wurden hier nicht ausgeführt oder getestet.
