"""PocketDeck receiver for Windows. Install: pip install pycaw comtypes pyautogui"""
import ctypes, json, os, secrets, socket, subprocess, threading, webbrowser, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from pycaw.pycaw import AudioUtilities
import pyautogui

CONFIG=Path(__file__).with_name('connection.json')
if CONFIG.exists():
    TOKEN=json.loads(CONFIG.read_text(encoding='utf-8'))['token']
else:
    TOKEN=secrets.token_hex(12)
    CONFIG.write_text(json.dumps({'token':TOKEN},indent=2),encoding='utf-8')

def audio():
    return AudioUtilities.GetSpeakers().EndpointVolume

def execute(action,value):
    if action=='volume': audio().SetMasterVolumeLevelScalar(max(0,min(100,int(value)))/100,None)
    elif action=='volume_up': pyautogui.press('volumeup')
    elif action=='volume_down': pyautogui.press('volumedown')
    elif action=='mute': pyautogui.press('volumemute')
    elif action=='play_pause': pyautogui.press('playpause')
    elif action=='next': pyautogui.press('nexttrack')
    elif action=='previous': pyautogui.press('prevtrack')
    elif action=='desktop': pyautogui.hotkey('win','d')
    elif action=='lock': ctypes.windll.user32.LockWorkStation()
    elif action=='screenshot': pyautogui.hotkey('win','shift','s')
    elif action=='browser': webbrowser.open('https://www.google.com')
    elif action=='notepad': subprocess.Popen(['notepad.exe'])
    elif action=='calculator': subprocess.Popen(['calc.exe'])
    elif action=='task_manager': pyautogui.hotkey('ctrl','shift','esc')
    elif action=='explorer': pyautogui.hotkey('win','e')
    elif action=='settings': pyautogui.hotkey('win','i')
    elif action=='search': pyautogui.hotkey('win','s')
    elif action=='run': pyautogui.hotkey('win','r')
    elif action=='copy': pyautogui.hotkey('ctrl','c')
    elif action=='paste': pyautogui.hotkey('ctrl','v')
    elif action=='cut': pyautogui.hotkey('ctrl','x')
    elif action=='undo': pyautogui.hotkey('ctrl','z')
    elif action=='redo': pyautogui.hotkey('ctrl','y')
    elif action=='save': pyautogui.hotkey('ctrl','s')
    elif action=='select_all': pyautogui.hotkey('ctrl','a')
    elif action=='new_tab': pyautogui.hotkey('ctrl','t')
    elif action=='close_tab': pyautogui.hotkey('ctrl','w')
    elif action=='switch_window': pyautogui.hotkey('alt','tab')
    elif action=='maximize': pyautogui.hotkey('win','up')
    elif action=='minimize': pyautogui.hotkey('win','down')
    elif action=='fullscreen': pyautogui.press('f11')
    elif action=='mic_mute': pyautogui.hotkey('win','alt','k')
    elif action=='emoji': pyautogui.hotkey('win','.')
    elif action=='refresh': pyautogui.press('f5')
    elif action=='show_notifications': pyautogui.hotkey('win','n')
    elif action=='quick_settings': pyautogui.hotkey('win','a')
    elif action=='record_screen': pyautogui.hotkey('win','alt','r')

    elif action in EXTRA_HOTKEYS: pyautogui.hotkey(*EXTRA_HOTKEYS[action])
    elif action in EXTRA_KEYS: pyautogui.press(EXTRA_KEYS[action])
    elif action=='hotkey':
        keys=str(value).lower().split('+')
        allowed={'ctrl','alt','shift','win','tab','enter','esc','space','up','down','left','right','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9','0','f1','f2','f3','f4','f5','f6','f7','f8','f9','f10','f11','f12'}
        if not 1<=len(keys)<=4 or any(k not in allowed for k in keys): raise ValueError('Ungültiger Hotkey')
        pyautogui.hotkey(*keys)
    elif action=='type_text':
        text=str(value)
        if len(text)>250: raise ValueError('Text zu lang')
        pyautogui.write(text,0.01)
    elif action=='open_url':
        from urllib.parse import urlsplit
        url=str(value)
        parsed=urlsplit(url)
        if len(url)>500 or parsed.scheme not in ('https','http') or not parsed.hostname: raise ValueError('Ungültige URL')
        webbrowser.open(url)
    elif action=='wait': time.sleep(min(5,max(0,float(value))))
    elif action=='macro':
        steps=str(value).split(',')
        if len(steps)>12: raise ValueError('Maximal 12 Makro-Schritte')
        for step in steps:
            if step not in SAFE_MACRO and step not in EXTRA_HOTKEYS and step not in EXTRA_KEYS: raise ValueError('Ungültiger Makro-Schritt')
            execute(step,0);time.sleep(0.12)
    else: raise ValueError('Unbekannte Aktion')
EXTRA_HOTKEYS={
 'new_window':('ctrl','n'),'incognito':('ctrl','shift','n'),'reopen_tab':('ctrl','shift','t'),
 'next_tab':('ctrl','tab'),'prev_tab':('ctrl','shift','tab'),'address_bar':('ctrl','l'),
 'find_text':('ctrl','f'),'print':('ctrl','p'),'zoom_in':('ctrl','+'),'zoom_out':('ctrl','-'),
 'zoom_reset':('ctrl','0'),'downloads':('ctrl','j'),'history':('ctrl','h'),
 'snap_left':('win','left'),'snap_right':('win','right'),'new_desktop':('win','ctrl','d'),
 'next_desktop':('win','ctrl','right'),'prev_desktop':('win','ctrl','left'),
 'close_desktop':('win','ctrl','f4'),'clipboard':('win','v'),'project':('win','p'),
 'connect':('win','k'),'display_settings':('win','i'),'widgets':('win','w'),
 'game_bar':('win','g'),'game_capture':('win','alt','prtsc'),
 'bold':('ctrl','b'),'italic':('ctrl','i'),'underline':('ctrl','u'),
 'new_file':('ctrl','n'),'open_file':('ctrl','o'),'find_replace':('ctrl','h'),
 'end_line':('end',),'start_line':('home',),'end_document':('ctrl','end'),
 'start_document':('ctrl','home'),'delete_line':('shift','end'),
 'terminal':('win','x'),'accessibility':('win','u'),
 'magnifier':('win','+'),'magnifier_close':('win','esc'),
 'task_view':('win','tab'),'properties':('alt','enter'),
 'rename':('f2',),'close_window':('alt','f4'),'switch_app':('alt','esc'),
 'screen_capture':('win','prtsc'),'dictation':('win','h')
}
EXTRA_KEYS={'escape':'esc','enter':'enter','tab':'tab','space':'space','delete':'delete','backspace':'backspace',
 'page_up':'pgup','page_down':'pgdn','home':'home','end':'end','arrow_up':'up','arrow_down':'down',
 'arrow_left':'left','arrow_right':'right','stop':'stop','browser_back':'browserback','browser_forward':'browserforward'}
SAFE_MACRO={'volume_up','volume_down','mute','play_pause','next','previous','desktop','screenshot','browser','notepad','calculator','task_manager','explorer','settings','search','copy','paste','cut','undo','redo','save','select_all','new_tab','close_tab','switch_window','maximize','minimize','fullscreen','refresh'}

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path!='/action': self.send_error(404);return
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length<1 or length>2048: self.send_error(413);return
            data=json.loads(self.rfile.read(length))
            if not secrets.compare_digest(str(data.get('token','')),TOKEN): self.send_error(403);return
            execute(data.get('action'),data.get('value',0))
            self.send_response(200);self.end_headers();self.wfile.write(b'OK')
        except Exception as exc:
            print('Fehler:',exc);self.send_error(400)

try:
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);sock.connect(('1.1.1.1',80));IP=sock.getsockname()[0];sock.close()
except OSError: IP=socket.gethostbyname(socket.gethostname())
print('=== POCKETDECK PC-EMPFÄNGER ===')
print('PC-IP:',IP,'Port: 8765')
print('Verbindungscode:',TOKEN)
print('Nur im vertrauenswürdigen Heim-WLAN verwenden. Strg+C beendet den Empfänger.')
ThreadingHTTPServer(('0.0.0.0',8765),Handler).serve_forever()
